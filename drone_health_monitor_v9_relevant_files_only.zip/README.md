# Drone Health Monitor RPi v9 - Picamera2 Visual Marker

This version keeps the drone health checks and email report system, and updates the CSI camera marker test to use Picamera2/libcamera on Raspberry Pi OS Bookworm.

## Important for Raspberry Pi CSI camera

If you use a Raspberry Pi camera connected by ribbon cable, install Picamera2 from apt and create the virtual environment with system packages:

```bash
sudo apt update
sudo apt install -y python3-picamera2 python3-opencv
python3 -m venv --system-site-packages venv
source venv/bin/activate
pip install -r requirements.txt
```

If you already created a venv without `--system-site-packages`, recreate it:

```bash
deactivate 2>/dev/null || true
rm -rf venv
python3 -m venv --system-site-packages venv
source venv/bin/activate
pip install -r requirements.txt
```

## Run visual marker test only

```bash
python src/run_marker_test.py --camera-backend picamera2 --camera-index 0 --duration 60 --send-email
```

With desktop preview:

```bash
python src/run_marker_test.py --camera-backend picamera2 --camera-index 0 --duration 60 --show
```

## Run full health test with marker detection

```bash
python src/main.py --connection /dev/ttyACM0 --baud 115200 --duration 180 --detect-marker --camera-backend picamera2 --camera-index 0 --email-on-marker --send-email
```

## Email configuration

This version does not require creating a new email file if you already have `.env` or `config/email_config.json` on the Raspberry Pi. Do not delete those files when replacing the code.

The existing email sender in this package reads `.env` with:

```env
EMAIL_FROM=your_gmail@gmail.com
EMAIL_PASSWORD=your_16_char_app_password
EMAIL_TO=receiver@gmail.com
```
