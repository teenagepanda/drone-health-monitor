import argparse
from pathlib import Path
from datetime import datetime
import pandas as pd


def safe_mean(df, col):
    if col not in df.columns:
        return "N/A"
    value = pd.to_numeric(df[col], errors="coerce").mean()
    return "N/A" if pd.isna(value) else f"{value:.2f}"


def safe_max(df, col):
    if col not in df.columns:
        return "N/A"
    value = pd.to_numeric(df[col], errors="coerce").max()
    return "N/A" if pd.isna(value) else f"{value:.2f}"


def generate_report(log_path: str, out_dir: str = "reports") -> Path:
    df = pd.read_csv(log_path)
    Path(out_dir).mkdir(exist_ok=True)

    status_counts = df["health_status"].value_counts().to_dict() if "health_status" in df else {}
    latest_messages = df["health_messages"].dropna().tail(10).tolist() if "health_messages" in df else []

    html = f"""
    <html>
    <head>
        <meta charset="utf-8">
        <title>Drone Health Report</title>
        <style>
            body {{ font-family: Arial, sans-serif; margin: 30px; }}
            table {{ border-collapse: collapse; width: 100%; }}
            td, th {{ border: 1px solid #ccc; padding: 8px; }}
            th {{ background: #eee; }}
            .ok {{ color: green; }}
            .warn {{ color: orange; }}
            .crit {{ color: red; }}
        </style>
    </head>
    <body>
        <h1>Drone Health Monitoring Report</h1>
        <p><b>Generated:</b> {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}</p>
        <p><b>Log file:</b> {log_path}</p>

        <h2>Summary</h2>
        <table>
            <tr><th>Metric</th><th>Value</th></tr>
            <tr><td>Samples</td><td>{len(df)}</td></tr>
            <tr><td>Average battery voltage</td><td>{safe_mean(df, "battery_voltage_v")} V</td></tr>
            <tr><td>Average battery current</td><td>{safe_mean(df, "battery_current_a")} A</td></tr>
            <tr><td>Average GPS satellites</td><td>{safe_mean(df, "gps_satellites")}</td></tr>
            <tr><td>Average GPS HDOP</td><td>{safe_mean(df, "gps_hdop")}</td></tr>
            <tr><td>Max RAW_IMU vibration RMS</td><td>{safe_max(df, "vibration_rms")} m/s²</td></tr>
            <tr><td>Max VIBE X</td><td>{safe_max(df, "vibe_x")}</td></tr>
            <tr><td>Max VIBE Y</td><td>{safe_max(df, "vibe_y")}</td></tr>
            <tr><td>Max VIBE Z</td><td>{safe_max(df, "vibe_z")}</td></tr>
            <tr><td>Max CPU temperature</td><td>{safe_max(df, "cpu_temp_c")} °C</td></tr>
        </table>

        <h2>Health Status Counts</h2>
        <pre>{status_counts}</pre>

        <h2>Latest Health Messages</h2>
        <ul>
            {''.join(f'<li>{m}</li>' for m in latest_messages)}
        </ul>

        <h2>Interpretation</h2>
        <p>
            High vibration may indicate unbalanced propellers, loose frame screws,
            motor bearing issues, poor flight-controller isolation, or frame resonance.
            GPS HDOP above the threshold may indicate weak GPS accuracy.
            ESC telemetry warnings are available only when the hardware and flight-controller firmware provide ESC telemetry.
        </p>
    </body>
    </html>
    """

    report_path = Path(out_dir) / f"drone_health_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.html"
    report_path.write_text(html, encoding="utf-8")
    return report_path


def main():
    parser = argparse.ArgumentParser(description="Generate drone health report from CSV log")
    parser.add_argument("--log", required=True, help="Path to CSV log file")
    parser.add_argument("--out-dir", default="reports")
    args = parser.parse_args()

    report = generate_report(args.log, args.out_dir)
    print(f"Report created: {report}")


if __name__ == "__main__":
    main()
