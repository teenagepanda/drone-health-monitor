from typing import List, Optional, Dict
import config


def active_motor_outputs(servo_outputs: List[Optional[int]]) -> List[int]:
    return [
        pwm for pwm in servo_outputs
        if pwm is not None and config.MOTOR_PWM_MIN_ACTIVE <= pwm <= config.MOTOR_PWM_MAX
    ]


def detect_motor_pwm_imbalance(servo_outputs: List[Optional[int]]) -> Optional[str]:
    active = active_motor_outputs(servo_outputs)
    if len(active) < 2:
        return None

    diff = max(active) - min(active)
    if diff >= config.MOTOR_IMBALANCE_WARNING_US:
        return f"Motor PWM imbalance detected: max-min={diff} us"
    return None


def detect_esc_anomalies(esc_dict: Dict[int, object]) -> List[str]:
    messages = []

    temps = []
    currents = []
    rpms = []

    for esc_id, esc in esc_dict.items():
        if esc.temperature_c is not None:
            temps.append((esc_id, esc.temperature_c))
            if esc.temperature_c >= config.ESC_TEMP_CRITICAL_C:
                messages.append(f"ESC {esc_id} critical temperature: {esc.temperature_c:.1f} C")
            elif esc.temperature_c >= config.ESC_TEMP_WARNING_C:
                messages.append(f"ESC {esc_id} high temperature: {esc.temperature_c:.1f} C")

        if esc.current_a is not None:
            currents.append((esc_id, esc.current_a))

        if esc.rpm is not None:
            rpms.append((esc_id, esc.rpm))

    messages.extend(_imbalance_messages("ESC current", currents, config.ESC_CURRENT_IMBALANCE_WARNING_PERCENT, "A"))
    messages.extend(_imbalance_messages("ESC RPM", rpms, config.ESC_RPM_IMBALANCE_WARNING_PERCENT, "RPM"))

    return messages


def _imbalance_messages(name, values, threshold_percent, unit):
    if len(values) < 2:
        return []

    numeric = [v for _, v in values if v is not None and v > 0]
    if len(numeric) < 2:
        return []

    avg = sum(numeric) / len(numeric)
    if avg <= 0:
        return []

    max_item = max(values, key=lambda x: x[1])
    min_item = min(values, key=lambda x: x[1])
    diff_percent = ((max_item[1] - min_item[1]) / avg) * 100.0

    if diff_percent >= threshold_percent:
        return [
            f"{name} imbalance: ESC {max_item[0]}={max_item[1]:.1f} {unit}, "
            f"ESC {min_item[0]}={min_item[1]:.1f} {unit}, diff={diff_percent:.1f}%"
        ]

    return []
