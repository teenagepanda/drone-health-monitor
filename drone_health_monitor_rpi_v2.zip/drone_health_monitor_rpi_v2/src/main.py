import argparse
import time

from mavlink_reader import MavlinkReader
from vibration import VibrationAnalyzer
from health_checks import check_drone_health
from logger import CsvLogger
from pi_health import get_cpu_temp_c, get_cpu_usage_percent, get_ram_usage_percent
import config


def main():
    parser = argparse.ArgumentParser(description="Drone health monitor for Raspberry Pi and Pixhawk USB")
    parser.add_argument("--connection", default=config.DEFAULT_CONNECTION,
                        help="USB MAVLink device, usually /dev/ttyACM0 for Pixhawk Type-C")
    parser.add_argument("--baud", type=int, default=config.DEFAULT_BAUD,
                        help="Serial baud rate. USB Pixhawk usually works with 115200.")
    parser.add_argument("--log-dir", default="logs",
                        help="Folder for CSV logs")
    args = parser.parse_args()

    reader = MavlinkReader(args.connection, args.baud)
    reader.connect()

    vibration = VibrationAnalyzer(window_size=100)
    logger = CsvLogger(args.log_dir)

    last_print = 0.0

    print("Monitoring started. Press CTRL+C to stop.")
    print("Safety: run first tests with propellers removed.")
    print("Connection mode: Raspberry Pi USB -> Pixhawk Type-C")

    try:
        while True:
            tel = reader.read_messages()

            vibration.add_sample(tel.acc_x, tel.acc_y, tel.acc_z)
            vib_rms = vibration.rms()

            cpu_temp = get_cpu_temp_c()
            cpu_usage = get_cpu_usage_percent()
            ram_usage = get_ram_usage_percent()

            health = check_drone_health(tel, vib_rms, cpu_temp, cpu_usage, ram_usage)
            logger.write(tel, vib_rms, cpu_temp, cpu_usage, ram_usage, health)

            now = time.time()
            if now - last_print >= config.STATUS_PRINT_INTERVAL_SECONDS:
                last_print = now
                print_status(tel, vib_rms, cpu_temp, cpu_usage, ram_usage, health)

            time.sleep(config.LOG_INTERVAL_SECONDS)

    except KeyboardInterrupt:
        print("\nMonitoring stopped by user.")
        print(f"CSV log saved at: {logger.path}")
    finally:
        logger.close()


def fmt(value, suffix="", digits=2):
    if value is None:
        return "N/A"
    if isinstance(value, float):
        return f"{value:.{digits}f}{suffix}"
    return f"{value}{suffix}"


def print_status(tel, vib_rms, cpu_temp, cpu_usage, ram_usage, health):
    esc_count = len(tel.esc)
    print("-" * 80)
    print(f"Status: {health.status}")
    print(f"Mode: {tel.mode} | Armed: {tel.armed}")
    print(f"Battery: {fmt(tel.battery_voltage_v, ' V')} | Current: {fmt(tel.battery_current_a, ' A')}"
          f" | Remaining: {fmt(tel.battery_remaining_percent, '%', 0)}")
    print(f"GPS: fix_type={tel.gps_fix_type} | satellites={tel.gps_satellites} | HDOP={fmt(tel.gps_hdop)}")
    print(f"RAW_IMU vibration RMS: {fmt(vib_rms, ' m/s^2')}")
    print(f"ArduPilot VIBE: X={fmt(tel.vibe_x)} | Y={fmt(tel.vibe_y)} | Z={fmt(tel.vibe_z)}")
    print(f"IMU clipping: {tel.clipping_0}, {tel.clipping_1}, {tel.clipping_2}")
    print(f"Servo outputs 1-4: {tel.servo_outputs[:4]}")
    print(f"ESC telemetry motors detected: {esc_count}")
    print(f"Pi CPU: {cpu_usage:.1f}% | RAM: {ram_usage:.1f}% | Temp: {fmt(cpu_temp, ' C')}")
    print("Messages:")
    for msg in health.messages:
        print(f" - {msg}")


if __name__ == "__main__":
    main()
