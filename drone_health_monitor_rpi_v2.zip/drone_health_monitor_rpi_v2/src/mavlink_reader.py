from dataclasses import dataclass, field
from typing import Optional, Dict, List
from pymavlink import mavutil
import time


@dataclass
class EscData:
    temperature_c: Optional[float] = None
    voltage_v: Optional[float] = None
    current_a: Optional[float] = None
    rpm: Optional[float] = None


@dataclass
class DroneTelemetry:
    timestamp: float
    armed: Optional[bool] = None
    mode: Optional[str] = None

    battery_voltage_v: Optional[float] = None
    battery_current_a: Optional[float] = None
    battery_remaining_percent: Optional[int] = None

    gps_fix_type: Optional[int] = None
    gps_satellites: Optional[int] = None
    gps_hdop: Optional[float] = None

    acc_x: Optional[float] = None
    acc_y: Optional[float] = None
    acc_z: Optional[float] = None

    roll_deg: Optional[float] = None
    pitch_deg: Optional[float] = None
    yaw_deg: Optional[float] = None

    vibe_x: Optional[float] = None
    vibe_y: Optional[float] = None
    vibe_z: Optional[float] = None
    clipping_0: Optional[int] = None
    clipping_1: Optional[int] = None
    clipping_2: Optional[int] = None

    servo_outputs: List[Optional[int]] = field(default_factory=lambda: [None] * 8)
    esc: Dict[int, EscData] = field(default_factory=dict)


class MavlinkReader:
    def __init__(self, connection: str, baud: int = 115200):
        self.connection = connection
        self.baud = baud
        self.master = None
        self.telemetry = DroneTelemetry(timestamp=time.time())

    def connect(self, timeout: int = 30) -> None:
        print(f"Connecting to Pixhawk on {self.connection} at {self.baud} baud...")
        self.master = mavutil.mavlink_connection(self.connection, baud=self.baud)
        self.master.wait_heartbeat(timeout=timeout)
        print("Heartbeat received. MAVLink connection is active.")

    def read_messages(self) -> DroneTelemetry:
        if self.master is None:
            raise RuntimeError("MAVLink is not connected. Call connect() first.")

        while True:
            msg = self.master.recv_match(blocking=False)
            if msg is None:
                break

            msg_type = msg.get_type()
            self.telemetry.timestamp = time.time()

            if msg_type == "HEARTBEAT":
                self.telemetry.armed = bool(
                    msg.base_mode & mavutil.mavlink.MAV_MODE_FLAG_SAFETY_ARMED
                )
                try:
                    self.telemetry.mode = mavutil.mode_string_v10(msg)
                except Exception:
                    self.telemetry.mode = "UNKNOWN"

            elif msg_type == "SYS_STATUS":
                if msg.voltage_battery != 65535:
                    self.telemetry.battery_voltage_v = msg.voltage_battery / 1000.0
                if msg.current_battery != -1:
                    self.telemetry.battery_current_a = msg.current_battery / 100.0
                if msg.battery_remaining != -1:
                    self.telemetry.battery_remaining_percent = int(msg.battery_remaining)

            elif msg_type == "GPS_RAW_INT":
                self.telemetry.gps_fix_type = int(msg.fix_type)
                self.telemetry.gps_satellites = int(msg.satellites_visible)
                # eph is HDOP * 100 in many MAVLink implementations.
                if getattr(msg, "eph", 65535) != 65535:
                    self.telemetry.gps_hdop = msg.eph / 100.0

            elif msg_type == "RAW_IMU":
                self.telemetry.acc_x = (msg.xacc / 1000.0) * 9.80665
                self.telemetry.acc_y = (msg.yacc / 1000.0) * 9.80665
                self.telemetry.acc_z = (msg.zacc / 1000.0) * 9.80665

            elif msg_type == "ATTITUDE":
                self.telemetry.roll_deg = msg.roll * 57.2958
                self.telemetry.pitch_deg = msg.pitch * 57.2958
                self.telemetry.yaw_deg = msg.yaw * 57.2958

            elif msg_type == "VIBRATION":
                self.telemetry.vibe_x = float(msg.vibration_x)
                self.telemetry.vibe_y = float(msg.vibration_y)
                self.telemetry.vibe_z = float(msg.vibration_z)
                self.telemetry.clipping_0 = int(msg.clipping_0)
                self.telemetry.clipping_1 = int(msg.clipping_1)
                self.telemetry.clipping_2 = int(msg.clipping_2)

            elif msg_type == "SERVO_OUTPUT_RAW":
                outputs = []
                for i in range(1, 9):
                    outputs.append(getattr(msg, f"servo{i}_raw", None))
                self.telemetry.servo_outputs = outputs

            elif msg_type.startswith("ESC_TELEMETRY_"):
                self._parse_esc_telemetry(msg, msg_type)

        return self.telemetry

    def _parse_esc_telemetry(self, msg, msg_type: str) -> None:
        """
        Supports ESC_TELEMETRY_1_TO_4, 5_TO_8, etc. when provided by ArduPilot.
        """
        try:
            # Example: ESC_TELEMETRY_1_TO_4 -> start index 1
            start = int(msg_type.split("_")[2])
        except Exception:
            start = 1

        for offset in range(4):
            esc_index = start + offset
            esc = self.telemetry.esc.get(esc_index, EscData())

            temperature = getattr(msg, "temperature", [None] * 4)
            voltage = getattr(msg, "voltage", [None] * 4)
            current = getattr(msg, "current", [None] * 4)
            rpm = getattr(msg, "rpm", [None] * 4)

            try:
                if temperature[offset] is not None:
                    esc.temperature_c = float(temperature[offset])
                if voltage[offset] is not None:
                    esc.voltage_v = float(voltage[offset]) / 100.0
                if current[offset] is not None:
                    esc.current_a = float(current[offset]) / 100.0
                if rpm[offset] is not None:
                    esc.rpm = float(rpm[offset])
            except Exception:
                pass

            self.telemetry.esc[esc_index] = esc
