import csv
from pathlib import Path
from datetime import datetime


class CsvLogger:
    def __init__(self, log_dir: str = "logs"):
        Path(log_dir).mkdir(exist_ok=True)
        filename = datetime.now().strftime("drone_health_%Y%m%d_%H%M%S.csv")
        self.path = Path(log_dir) / filename
        self.file = open(self.path, "w", newline="")
        self.writer = csv.writer(self.file)

        self.writer.writerow([
            "timestamp",
            "armed", "mode",
            "battery_voltage_v", "battery_current_a", "battery_remaining_percent",
            "gps_fix_type", "gps_satellites", "gps_hdop",
            "acc_x", "acc_y", "acc_z",
            "roll_deg", "pitch_deg", "yaw_deg",
            "vibration_rms",
            "vibe_x", "vibe_y", "vibe_z",
            "clipping_0", "clipping_1", "clipping_2",
            "servo1", "servo2", "servo3", "servo4",
            "servo5", "servo6", "servo7", "servo8",
            "esc_summary",
            "cpu_temp_c", "cpu_usage_percent", "ram_usage_percent",
            "health_status", "health_messages"
        ])

    def write(self, tel, vibration_rms, cpu_temp, cpu_usage, ram_usage, health):
        esc_summary = []
        for esc_id, esc in sorted(tel.esc.items()):
            esc_summary.append(
                f"ESC{esc_id}:temp={esc.temperature_c},v={esc.voltage_v},i={esc.current_a},rpm={esc.rpm}"
            )

        self.writer.writerow([
            tel.timestamp,
            tel.armed, tel.mode,
            tel.battery_voltage_v, tel.battery_current_a, tel.battery_remaining_percent,
            tel.gps_fix_type, tel.gps_satellites, tel.gps_hdop,
            tel.acc_x, tel.acc_y, tel.acc_z,
            tel.roll_deg, tel.pitch_deg, tel.yaw_deg,
            vibration_rms,
            tel.vibe_x, tel.vibe_y, tel.vibe_z,
            tel.clipping_0, tel.clipping_1, tel.clipping_2,
            *tel.servo_outputs[:8],
            " ; ".join(esc_summary),
            cpu_temp, cpu_usage, ram_usage,
            health.status, " | ".join(health.messages)
        ])
        self.file.flush()

    def close(self):
        self.file.close()
