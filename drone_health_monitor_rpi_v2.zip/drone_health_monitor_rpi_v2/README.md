# Drone Health Monitor V2 — Raspberry Pi + Pixhawk USB

Python health-monitoring project for Raspberry Pi connected to a Pixhawk flight controller by USB:
- Raspberry Pi USB-A / USB-C
- Pixhawk Type-C USB port

Default connection:
```bash
/dev/ttyACM0
```

## Features
- MAVLink connection check
- Armed / flight mode check
- Battery voltage/current check
- GPS fix + satellites + HDOP check
- IMU vibration RMS from RAW_IMU
- ArduPilot VIBE message monitoring
- ESC telemetry monitoring, if available
- Motor-output monitoring from SERVO_OUTPUT_RAW
- Basic motor anomaly detection
- Raspberry Pi CPU/RAM/temperature check
- CSV logging
- HTML report generation

## Important safety
First run all tests with propellers removed.

## Install on Raspberry Pi
```bash
sudo apt update
sudo apt install python3-pip python3-venv -y

python3 -m venv .venv
source .venv/bin/activate

pip install -r requirements.txt
```

## Run with USB connection
Connect Pixhawk Type-C to Raspberry Pi USB, then run:

```bash
python3 src/main.py --connection /dev/ttyACM0 --baud 115200
```

If `/dev/ttyACM0` does not work, check ports:

```bash
ls /dev/ttyACM*
ls /dev/ttyUSB*
```

Then run for example:

```bash
python3 src/main.py --connection /dev/ttyACM1 --baud 115200
```

## Create report from latest log
```bash
python3 src/report_generator.py --log logs/YOUR_LOG.csv
```

The report will be saved in the `reports/` folder.

## Notes
- VIBE messages are supported mainly by ArduPilot.
- ESC telemetry requires ESCs and flight-controller setup that actually send ESC telemetry.
- Motor-output monitoring from SERVO_OUTPUT_RAW checks PWM output differences, not physical RPM.
