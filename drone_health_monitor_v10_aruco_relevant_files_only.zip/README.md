# Drone Health Monitor - v10 ArUco marker update

This update adds ArUco marker detection for the visual-marker test. ArUco is preferred over template matching because it is more stable with rotation, perspective changes and different distances.

Default marker:

- Dictionary: `4x4_50`
- ID: `23`
- File: `markers/aruco_4x4_50_id23.png`

Marker-only test:

```bash
python src/run_marker_test.py --camera-backend picamera2 --marker-type aruco --aruco-id 23 --duration 60 --show --send-email
```

Full health test with marker detection:

```bash
python src/main.py --connection /dev/ttyACM0 --baud 115200 --duration 180 --detect-marker --camera-backend picamera2 --marker-type aruco --aruco-id 23 --email-on-marker --send-email
```

Generate a new marker if needed:

```bash
python src/generate_aruco_marker.py --id 23 --dictionary 4x4_50 --output markers/aruco_4x4_50_id23.png
```

If OpenCV says that `aruco` is missing, install Raspberry Pi OpenCV and recreate the venv with system packages:

```bash
sudo apt install -y python3-opencv python3-picamera2
deactivate
rm -rf venv
python3 -m venv --system-site-packages venv
source venv/bin/activate
pip install -r requirements.txt
```
