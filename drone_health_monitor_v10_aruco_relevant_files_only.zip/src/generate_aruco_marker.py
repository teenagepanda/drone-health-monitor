from __future__ import annotations

import argparse
from pathlib import Path

import cv2

DICTIONARIES = {
    "4x4_50": cv2.aruco.DICT_4X4_50,
    "4x4_100": cv2.aruco.DICT_4X4_100,
    "5x5_50": cv2.aruco.DICT_5X5_50,
    "5x5_100": cv2.aruco.DICT_5X5_100,
    "6x6_50": cv2.aruco.DICT_6X6_50,
    "6x6_100": cv2.aruco.DICT_6X6_100,
}


def main():
    parser = argparse.ArgumentParser(description="Generate an ArUco marker image")
    parser.add_argument("--id", type=int, default=23, help="ArUco marker ID")
    parser.add_argument("--dictionary", choices=sorted(DICTIONARIES.keys()), default="4x4_50")
    parser.add_argument("--size", type=int, default=800, help="Marker image size in pixels")
    parser.add_argument("--output", default="markers/aruco_4x4_50_id23.png")
    args = parser.parse_args()

    dictionary = cv2.aruco.getPredefinedDictionary(DICTIONARIES[args.dictionary])
    if hasattr(cv2.aruco, "generateImageMarker"):
        marker = cv2.aruco.generateImageMarker(dictionary, args.id, args.size)
    else:
        marker = cv2.aruco.drawMarker(dictionary, args.id, args.size)

    output_path = Path(args.output)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    cv2.imwrite(str(output_path), marker)
    print(f"ArUco marker saved: {output_path}")
    print(f"Dictionary: {args.dictionary} | ID: {args.id}")


if __name__ == "__main__":
    main()
