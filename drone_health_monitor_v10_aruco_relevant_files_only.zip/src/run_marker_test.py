import argparse
import time
from pathlib import Path

import cv2

from camera_capture import CameraCapture
from email_sender import send_email_report


def main():
    parser = argparse.ArgumentParser(description="Run camera test for visual-marker detection")
    parser.add_argument("--camera-index", type=int, default=0, help="Camera index, usually 0")
    parser.add_argument("--camera-backend", choices=["auto", "picamera2", "opencv"], default="auto", help="Camera backend. Use picamera2 for Raspberry Pi CSI camera")
    parser.add_argument("--marker-type", choices=["aruco", "template"], default="aruco", help="Marker detection method")
    parser.add_argument("--aruco-id", type=int, default=23, help="Target ArUco marker ID")
    parser.add_argument("--aruco-dictionary", choices=["4x4_50", "4x4_100", "5x5_50", "5x5_100", "6x6_50", "6x6_100"], default="4x4_50", help="ArUco dictionary")
    parser.add_argument("--reference", default="markers/reference_marker.png", help="Reference marker image path for template mode")
    parser.add_argument("--duration", type=int, default=60, help="Test duration in seconds")
    parser.add_argument("--threshold", type=float, default=0.72, help="Template detection score threshold")
    parser.add_argument("--send-email", action="store_true", help="Send email when marker is detected")
    parser.add_argument("--show", action="store_true", help="Show camera window on desktop")
    parser.add_argument("--save-detected-frame", default="reports/marker_detected.jpg", help="Path to save detected frame")
    args = parser.parse_args()

    if args.marker_type == "aruco":
        from aruco_marker_detector import ArucoMarkerDetector, draw_aruco_detection
        detector = ArucoMarkerDetector(marker_id=args.aruco_id, dictionary_name=args.aruco_dictionary)
        draw_detection = draw_aruco_detection
        detector_description = f"ArUco {args.aruco_dictionary} ID {args.aruco_id}"
    else:
        from visual_marker_detector import VisualMarkerDetector, draw_detection
        detector = VisualMarkerDetector(args.reference, threshold=args.threshold)
        detector_description = f"Template marker reference={args.reference}"

    cap = CameraCapture(camera_index=args.camera_index, backend=args.camera_backend)
    cap.open()
    print(f"Camera backend: {cap.active_backend}")
    print(f"Marker detector: {detector_description}")

    print(f"Visual marker test started for {args.duration} seconds.")
    print("Show the marker to the camera. Press q to stop if --show is used.")

    start = time.time()
    last_print = 0.0
    email_sent = False
    detected_once = False
    saved_frame_path = None

    try:
        while time.time() - start < args.duration:
            camera_frame = cap.read()
            if not camera_frame.ok:
                print(f"Camera frame not received. {camera_frame.message}")
                time.sleep(0.2)
                continue

            frame = camera_frame.frame
            detection = detector.detect(frame)
            now = time.time()

            if now - last_print >= 1.0:
                last_print = now
                if detection.detected:
                    extra = f" | id={getattr(detection, 'marker_id', '')}" if getattr(detection, "marker_id", None) is not None else ""
                    print(f"✅ Visual marker detected{extra}")
                else:
                    print(f"Marker not detected | {detection.message}")

            if detection.detected and not detected_once:
                detected_once = True
                save_path = Path(args.save_detected_frame)
                save_path.parent.mkdir(parents=True, exist_ok=True)
                cv2.imwrite(str(save_path), draw_detection(frame, detection))
                saved_frame_path = str(save_path)
                print(f"Detected frame saved: {saved_frame_path}")

                if args.send_email and not email_sent:
                    marker_body = detection.message
                    send_email_report(
                        subject="Drone Visual Marker Detected",
                        body=f"The drone camera detected the visual marker.\n{marker_body}",
                        attachments=[saved_frame_path],
                    )
                    email_sent = True
                    print("Email notification sent successfully.")

            if args.show:
                cv2.imshow("Visual Marker Test", draw_detection(frame, detection))
                if cv2.waitKey(1) & 0xFF == ord("q"):
                    break

            time.sleep(0.05)
    finally:
        cap.close()
        if args.show:
            cv2.destroyAllWindows()

    if detected_once:
        print("FINAL RESULT: visual marker was detected.")
    else:
        print("FINAL RESULT: visual marker was not detected during the test.")


if __name__ == "__main__":
    main()
