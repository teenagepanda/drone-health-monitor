from pathlib import Path
from datetime import datetime
import pandas as pd


def numeric(df, col):
    if col not in df.columns:
        return pd.Series(dtype=float)
    return pd.to_numeric(df[col], errors="coerce")


def avg(df, col):
    values = numeric(df, col).dropna()
    return None if values.empty else float(values.mean())


def min_val(df, col):
    values = numeric(df, col).dropna()
    return None if values.empty else float(values.min())


def max_val(df, col):
    values = numeric(df, col).dropna()
    return None if values.empty else float(values.max())


def status_line(name, status, message):
    return f"<tr><td><b>{name}</b></td><td>{status}</td><td>{message}</td></tr>"


def friendly_status_rows(df):
    rows = []
    plain_lines = []

    battery_v = avg(df, "battery_voltage_v")
    battery_min = min_val(df, "battery_voltage_v")
    battery_percent = avg(df, "battery_remaining_percent")
    current_a = avg(df, "battery_current_a")

    if battery_v is None:
        rows.append(status_line("סוללה", "⚠️ חסר מידע", "לא התקבלו נתוני סוללה מהבקר."))
        plain_lines.append("סוללה: חסר מידע — לא התקבלו נתוני סוללה.")
    elif battery_v >= 21.0:
        msg = f"תקינה לשימוש — מתח ממוצע {battery_v:.2f}V, מתח מינימלי {battery_min:.2f}V, אחוז ממוצע {battery_percent:.0f}%."
        rows.append(status_line("סוללה", "✅ תקינה", msg))
        plain_lines.append(f"סוללה: תקינה לשימוש — מתח ממוצע {battery_v:.2f}V, מתח מינימלי {battery_min:.2f}V, אחוז ממוצע {battery_percent:.0f}%.")
    elif battery_v >= 20.0:
        msg = f"אזהרה — מתח ממוצע {battery_v:.2f}V. מומלץ להטעין לפני טיסה ארוכה."
        rows.append(status_line("סוללה", "⚠️ אזהרה", msg))
        plain_lines.append(f"סוללה: אזהרה — מתח ממוצע {battery_v:.2f}V. מומלץ להטעין.")
    else:
        msg = f"לא תקינה לטיסה — מתח ממוצע {battery_v:.2f}V נמוך מדי."
        rows.append(status_line("סוללה", "❌ לא תקינה", msg))
        plain_lines.append(f"סוללה: לא תקינה לטיסה — מתח ממוצע {battery_v:.2f}V נמוך מדי.")

    gps_fix = avg(df, "gps_fix_type")
    sats = avg(df, "gps_satellites")
    hdop = avg(df, "gps_hdop")

    if gps_fix is None or sats is None or hdop is None:
        rows.append(status_line("GPS", "⚠️ חסר מידע", "לא התקבלו נתוני GPS מלאים."))
        plain_lines.append("GPS: חסר מידע — לא התקבלו נתוני GPS מלאים.")
    elif gps_fix >= 3 and sats >= 8 and hdop < 1.5:
        msg = f"תקין — Fix Type {gps_fix:.0f}, ממוצע {sats:.0f} לוויינים, HDOP ממוצע {hdop:.2f}."
        rows.append(status_line("GPS", "✅ תקין", msg))
        plain_lines.append(f"GPS: תקין — {sats:.0f} לוויינים בממוצע, HDOP ממוצע {hdop:.2f}.")
    elif gps_fix >= 3 and sats >= 8 and hdop < 2.5:
        msg = f"עובד אך גבולי — HDOP ממוצע {hdop:.2f}. מומלץ לבדוק בחוץ או ליד חלון."
        rows.append(status_line("GPS", "⚠️ גבולי", msg))
        plain_lines.append(f"GPS: גבולי — HDOP ממוצע {hdop:.2f}. מומלץ לבדוק בחוץ.")
    else:
        msg = f"לא יציב — Fix Type {gps_fix:.0f}, לוויינים {sats:.0f}, HDOP {hdop:.2f}."
        rows.append(status_line("GPS", "❌ לא יציב", msg))
        plain_lines.append(f"GPS: לא יציב — Fix Type {gps_fix:.0f}, לוויינים {sats:.0f}, HDOP {hdop:.2f}.")

    vib = avg(df, "vibration_rms")
    vibe_x = avg(df, "vibe_x")
    vibe_y = avg(df, "vibe_y")
    vibe_z = avg(df, "vibe_z")
    max_vibe = max([v for v in [vibe_x, vibe_y, vibe_z] if v is not None], default=None)

    if vib is None:
        rows.append(status_line("רעידות IMU", "⚠️ חסר מידע", "לא נאספו מספיק דגימות רעידות."))
        plain_lines.append("רעידות IMU: חסר מידע — לא נאספו מספיק דגימות.")
    elif vib < 3.0 and (max_vibe is None or max_vibe < 30):
        msg = f"תקין — RMS ממוצע {vib:.3f} m/s², VIBE מקסימלי ממוצע {max_vibe:.3f}."
        rows.append(status_line("רעידות IMU", "✅ תקין", msg))
        plain_lines.append(f"רעידות IMU: תקין — RMS ממוצע {vib:.3f} m/s².")
    elif vib < 6.0:
        msg = f"גבולי — RMS ממוצע {vib:.2f} m/s². כדאי לבדוק ברגים, מנועים ואיזון פרופלורים."
        rows.append(status_line("רעידות IMU", "⚠️ גבולי", msg))
        plain_lines.append(f"רעידות IMU: גבולי — RMS ממוצע {vib:.2f} m/s².")
    else:
        msg = f"לא תקין — RMS ממוצע {vib:.2f} m/s² גבוה מדי."
        rows.append(status_line("רעידות IMU", "❌ לא תקין", msg))
        plain_lines.append(f"רעידות IMU: לא תקין — RMS ממוצע {vib:.2f} m/s² גבוה מדי.")

    clip0 = max_val(df, "clipping_0") or 0
    clip1 = max_val(df, "clipping_1") or 0
    clip2 = max_val(df, "clipping_2") or 0

    if clip0 == 0 and clip1 == 0 and clip2 == 0:
        rows.append(status_line("IMU Clipping", "✅ תקין", "לא זוהו חריגות Clipping בחיישני ה־IMU."))
        plain_lines.append("IMU Clipping: תקין — לא זוהו חריגות.")
    else:
        rows.append(status_line("IMU Clipping", "⚠️ אזהרה", f"זוהה Clipping: {clip0}, {clip1}, {clip2}."))
        plain_lines.append(f"IMU Clipping: אזהרה — זוהה Clipping: {clip0}, {clip1}, {clip2}.")

    cpu_temp = avg(df, "cpu_temp_c")
    cpu_usage = avg(df, "cpu_usage_percent")
    ram_usage = avg(df, "ram_usage_percent")

    if cpu_temp is None:
        rows.append(status_line("Raspberry Pi", "⚠️ חסר מידע", "לא התקבלו נתוני טמפרטורת CPU."))
        plain_lines.append("Raspberry Pi: חסר מידע — אין נתוני טמפרטורת CPU.")
    elif cpu_temp < 70 and cpu_usage < 85 and ram_usage < 85:
        msg = f"תקין — טמפרטורת CPU ממוצעת {cpu_temp:.1f}°C, שימוש CPU {cpu_usage:.1f}%, RAM {ram_usage:.1f}%."
        rows.append(status_line("Raspberry Pi", "✅ תקין", msg))
        plain_lines.append(f"Raspberry Pi: תקין — טמפרטורה {cpu_temp:.1f}°C, CPU {cpu_usage:.1f}%, RAM {ram_usage:.1f}%.")
    else:
        msg = f"אזהרה — טמפ׳ {cpu_temp:.1f}°C, CPU {cpu_usage:.1f}%, RAM {ram_usage:.1f}%."
        rows.append(status_line("Raspberry Pi", "⚠️ אזהרה", msg))
        plain_lines.append(f"Raspberry Pi: אזהרה — טמפ׳ {cpu_temp:.1f}°C, CPU {cpu_usage:.1f}%, RAM {ram_usage:.1f}%.")

    return rows, plain_lines


def metric_row(df, label, col, unit=""):
    values = numeric(df, col).dropna()
    if values.empty:
        return f"<tr><td>{label}</td><td>N/A</td><td>N/A</td><td>N/A</td><td>{unit}</td></tr>"
    return (
        f"<tr><td>{label}</td>"
        f"<td>{values.mean():.2f}</td>"
        f"<td>{values.min():.2f}</td>"
        f"<td>{values.max():.2f}</td>"
        f"<td>{unit}</td></tr>"
    )


def generate_report(log_path: str, out_dir: str = "reports") -> Path:
    df = pd.read_csv(log_path)
    Path(out_dir).mkdir(exist_ok=True)

    friendly_rows, plain_lines = friendly_status_rows(df)
    status_counts = df["health_status"].value_counts().to_dict() if "health_status" in df else {}

    metric_rows = [
        metric_row(df, "Battery Voltage", "battery_voltage_v", "V"),
        metric_row(df, "Battery Current", "battery_current_a", "A"),
        metric_row(df, "GPS Satellites", "gps_satellites", ""),
        metric_row(df, "GPS HDOP", "gps_hdop", ""),
        metric_row(df, "RAW_IMU Vibration RMS", "vibration_rms", "m/s²"),
        metric_row(df, "VIBE X", "vibe_x", ""),
        metric_row(df, "VIBE Y", "vibe_y", ""),
        metric_row(df, "VIBE Z", "vibe_z", ""),
        metric_row(df, "CPU Temperature", "cpu_temp_c", "°C"),
        metric_row(df, "CPU Usage", "cpu_usage_percent", "%"),
        metric_row(df, "RAM Usage", "ram_usage_percent", "%"),
    ]

    html = f"""<!doctype html>
<html lang="he" dir="rtl">
<head>
<meta charset="utf-8">
<title>Drone Health Friendly Report</title>
<style>
body {{ font-family: Arial, sans-serif; margin: 30px; direction: rtl; }}
table {{ border-collapse: collapse; width: 100%; margin-top: 10px; }}
td, th {{ border: 1px solid #cccccc; padding: 10px; text-align: right; }}
th {{ background: #eeeeee; }}
.box {{ background: #f7f7f7; border: 1px solid #dddddd; padding: 15px; border-radius: 8px; }}
</style>
</head>
<body>
<h1>דוח תקינות מערכת הרחפן</h1>
<p><b>תאריך יצירה:</b> {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}</p>
<p><b>קובץ לוג:</b> {Path(log_path).name}</p>
<p><b>מספר דגימות:</b> {len(df)}</p>

<div class="box">
<h2>סיכום פשוט למשתמש</h2>
<table>
<tr><th>מערכת</th><th>מצב</th><th>פירוט</th></tr>
{''.join(friendly_rows)}
</table>
</div>

<h2>נתונים מספריים</h2>
<table>
<tr><th>מדד</th><th>ממוצע</th><th>מינימום</th><th>מקסימום</th><th>יחידה</th></tr>
{''.join(metric_rows)}
</table>

<h2>ספירת מצבי מערכת</h2>
<pre>{status_counts}</pre>

<h2>הערה</h2>
<p>
הדוח מיועד לבדיקה התחלתית. לפני טיסה אמיתית יש לבדוק גם ב־Mission Planner/QGroundControl:
ARM, GPS, EKF, מצפן, כיוון מנועים ו־Failsafe.
</p>
</body>
</html>"""

    report_path = Path(out_dir) / f"friendly_drone_health_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.html"
    report_path.write_text(html, encoding="utf-8")
    return report_path


def text_summary(log_path: str) -> str:
    df = pd.read_csv(log_path)
    _, plain_lines = friendly_status_rows(df)

    return """דוח תקינות מערכת הרחפן

סיכום פשוט:
""" + "\n".join(plain_lines) + f"""

מספר דגימות: {len(df)}

מצורפים למייל:
1. דוח HTML ידידותי
2. קובץ CSV מלא עם כל הנתונים
"""
