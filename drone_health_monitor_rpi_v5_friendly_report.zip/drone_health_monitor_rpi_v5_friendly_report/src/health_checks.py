from dataclasses import dataclass
from typing import List, Optional
import config


@dataclass
class HealthResult:
    status: str
    messages: List[str]


def worst_status(current: str, new: str) -> str:
    priority = {"OK": 0, "WARNING": 1, "CRITICAL": 2}
    return new if priority[new] > priority[current] else current


def check_drone_health(tel, vibration_rms: Optional[float], cpu_temp: Optional[float],
                       cpu_usage: float, ram_usage: float) -> HealthResult:
    status = "OK"
    messages = []

    if tel.battery_voltage_v is None:
        status = worst_status(status, "WARNING")
        messages.append("Battery telemetry missing")
    elif tel.battery_voltage_v <= config.BATTERY_CRITICAL_VOLTAGE:
        status = worst_status(status, "CRITICAL")
        messages.append(f"Battery critical: {tel.battery_voltage_v:.2f} V")
    elif tel.battery_voltage_v <= config.BATTERY_MIN_VOLTAGE:
        status = worst_status(status, "WARNING")
        messages.append(f"Battery low: {tel.battery_voltage_v:.2f} V")

    if tel.gps_fix_type is None:
        status = worst_status(status, "WARNING")
        messages.append("GPS telemetry missing")
    else:
        if tel.gps_fix_type < config.MIN_GPS_FIX_TYPE:
            status = worst_status(status, "WARNING")
            messages.append(f"GPS fix weak: fix_type={tel.gps_fix_type}")
        if tel.gps_satellites is not None and tel.gps_satellites < config.MIN_GPS_SATELLITES:
            status = worst_status(status, "WARNING")
            messages.append(f"Low GPS satellites: {tel.gps_satellites}")
        if tel.gps_hdop is not None:
            if tel.gps_hdop >= config.GPS_HDOP_CRITICAL:
                status = worst_status(status, "CRITICAL")
                messages.append(f"GPS HDOP critical: {tel.gps_hdop:.2f}")
            elif tel.gps_hdop >= config.GPS_HDOP_WARNING:
                status = worst_status(status, "WARNING")
                messages.append(f"GPS HDOP warning: {tel.gps_hdop:.2f}")

    if vibration_rms is None:
        status = worst_status(status, "WARNING")
        messages.append("Not enough IMU samples for vibration RMS")
    elif vibration_rms >= config.VIBRATION_CRITICAL_RMS:
        status = worst_status(status, "CRITICAL")
        messages.append(f"Critical RAW_IMU vibration RMS: {vibration_rms:.2f} m/s^2")
    elif vibration_rms >= config.VIBRATION_WARNING_RMS:
        status = worst_status(status, "WARNING")
        messages.append(f"High RAW_IMU vibration RMS: {vibration_rms:.2f} m/s^2")

    vibe_values = [tel.vibe_x, tel.vibe_y, tel.vibe_z]
    if all(v is not None for v in vibe_values):
        max_vibe = max(vibe_values)
        if max_vibe >= config.VIBE_CRITICAL:
            status = worst_status(status, "CRITICAL")
            messages.append(f"ArduPilot VIBE critical: max={max_vibe:.1f}")
        elif max_vibe >= config.VIBE_WARNING:
            status = worst_status(status, "WARNING")
            messages.append(f"ArduPilot VIBE high: max={max_vibe:.1f}")

    clipping_values = [tel.clipping_0, tel.clipping_1, tel.clipping_2]
    if any(c is not None and c >= config.CLIPPING_WARNING for c in clipping_values):
        status = worst_status(status, "WARNING")
        messages.append(f"IMU clipping detected: {clipping_values}")

    if cpu_temp is not None:
        if cpu_temp >= config.CPU_TEMP_CRITICAL_C:
            status = worst_status(status, "CRITICAL")
            messages.append(f"CPU temperature critical: {cpu_temp:.1f} C")
        elif cpu_temp >= config.CPU_TEMP_WARNING_C:
            status = worst_status(status, "WARNING")
            messages.append(f"CPU temperature high: {cpu_temp:.1f} C")

    if cpu_usage >= config.CPU_USAGE_WARNING_PERCENT:
        status = worst_status(status, "WARNING")
        messages.append(f"High CPU usage: {cpu_usage:.1f}%")

    if ram_usage >= config.RAM_USAGE_WARNING_PERCENT:
        status = worst_status(status, "WARNING")
        messages.append(f"High RAM usage: {ram_usage:.1f}%")

    if not messages:
        messages.append("All monitored systems look normal")

    return HealthResult(status=status, messages=messages)
