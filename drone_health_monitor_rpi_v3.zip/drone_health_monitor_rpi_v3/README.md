# Drone Health Monitor V3 — Raspberry Pi + Pixhawk USB + Email Report

Runs a timed drone health test, logs MAVLink telemetry, creates an HTML report, and sends the report by email.

## Connection
Raspberry Pi USB → Pixhawk Type-C

Default port:
```bash
/dev/ttyACM0
```

## Install
```bash
sudo apt update
sudo apt install -y python3-dev build-essential python3-pip python3-setuptools python3-wheel

python3 -m venv .venv
source .venv/bin/activate

pip install --upgrade pip setuptools wheel
pip install -r requirements.txt
```

## Configure email safely
```bash
cp .env.example .env
nano .env
```

Inside `.env`:
```text
EMAIL_FROM=your_email@gmail.com
EMAIL_PASSWORD=your_google_app_password
EMAIL_TO=your_email@gmail.com
```

Use Gmail App Password, not your normal Gmail password.

## Run 3-minute health test and send email
```bash
source .venv/bin/activate
python3 src/run_health_test.py --connection /dev/ttyACM0 --baud 115200 --duration 180 --send-email
```

## Run without email
```bash
python3 src/run_health_test.py --connection /dev/ttyACM0 --baud 115200 --duration 180
```

## Safety
First tests should be done without propellers.
