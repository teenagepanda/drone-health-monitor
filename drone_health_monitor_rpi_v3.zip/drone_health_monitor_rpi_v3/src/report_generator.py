from pathlib import Path
from datetime import datetime
import pandas as pd


def numeric(df, col):
    if col not in df.columns:
        return pd.Series(dtype=float)
    return pd.to_numeric(df[col], errors="coerce")


def metric_row(df, label, col, unit=""):
    values = numeric(df, col).dropna()
    if values.empty:
        return f"<tr><td>{label}</td><td>N/A</td><td>N/A</td><td>N/A</td><td>{unit}</td></tr>"

    return (
        f"<tr><td>{label}</td>"
        f"<td>{values.mean():.2f}</td>"
        f"<td>{values.min():.2f}</td>"
        f"<td>{values.max():.2f}</td>"
        f"<td>{unit}</td></tr>"
    )


def generate_report(log_path: str, out_dir: str = "reports") -> Path:
    df = pd.read_csv(log_path)
    Path(out_dir).mkdir(exist_ok=True)

    status_counts = df["health_status"].value_counts().to_dict() if "health_status" in df else {}
    latest_status = df["health_status"].dropna().iloc[-1] if "health_status" in df and not df["health_status"].dropna().empty else "N/A"
    latest_messages = df["health_messages"].dropna().tail(10).tolist() if "health_messages" in df else []

    rows = [
        metric_row(df, "Battery Voltage", "battery_voltage_v", "V"),
        metric_row(df, "Battery Current", "battery_current_a", "A"),
        metric_row(df, "GPS Satellites", "gps_satellites", ""),
        metric_row(df, "GPS HDOP", "gps_hdop", ""),
        metric_row(df, "RAW_IMU Vibration RMS", "vibration_rms", "m/s²"),
        metric_row(df, "ArduPilot VIBE X", "vibe_x", ""),
        metric_row(df, "ArduPilot VIBE Y", "vibe_y", ""),
        metric_row(df, "ArduPilot VIBE Z", "vibe_z", ""),
        metric_row(df, "CPU Temperature", "cpu_temp_c", "°C"),
        metric_row(df, "CPU Usage", "cpu_usage_percent", "%"),
        metric_row(df, "RAM Usage", "ram_usage_percent", "%"),
    ]

    html = f"""<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Drone Health Report</title>
<style>
body {{ font-family: Arial, sans-serif; margin: 30px; }}
table {{ border-collapse: collapse; width: 100%; margin-top: 10px; }}
td, th {{ border: 1px solid #cccccc; padding: 8px; text-align: left; }}
th {{ background: #eeeeee; }}
</style>
</head>
<body>
<h1>Drone Health Monitoring Report</h1>
<p><b>Generated:</b> {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}</p>
<p><b>Log file:</b> {Path(log_path).name}</p>
<p><b>Samples:</b> {len(df)}</p>
<p><b>Latest status:</b> {latest_status}</p>

<h2>Average / Minimum / Maximum</h2>
<table>
<tr><th>Metric</th><th>Average</th><th>Minimum</th><th>Maximum</th><th>Unit</th></tr>
{''.join(rows)}
</table>

<h2>Status Counts</h2>
<pre>{status_counts}</pre>

<h2>Latest Messages</h2>
<ul>
{''.join(f'<li>{m}</li>' for m in latest_messages)}
</ul>

<h2>Interpretation</h2>
<p>
For GPS, lower HDOP is better. Values below 1.5 are usually acceptable for testing.
High vibration can indicate unbalanced propellers, loose frame screws, motor issues,
or poor flight-controller isolation.
</p>
</body>
</html>"""

    report_path = Path(out_dir) / f"drone_health_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.html"
    report_path.write_text(html, encoding="utf-8")
    return report_path


def text_summary(log_path: str) -> str:
    df = pd.read_csv(log_path)

    def avg(col):
        values = numeric(df, col).dropna()
        return "N/A" if values.empty else f"{values.mean():.2f}"

    latest_status = df["health_status"].dropna().iloc[-1] if "health_status" in df and not df["health_status"].dropna().empty else "N/A"
    latest_message = df["health_messages"].dropna().iloc[-1] if "health_messages" in df and not df["health_messages"].dropna().empty else "N/A"

    return f"""Drone Health Monitoring Summary

Samples: {len(df)}
Latest Status: {latest_status}

Averages:
Battery Voltage: {avg("battery_voltage_v")} V
Battery Current: {avg("battery_current_a")} A
GPS Satellites: {avg("gps_satellites")}
GPS HDOP: {avg("gps_hdop")}
RAW_IMU Vibration RMS: {avg("vibration_rms")} m/s^2
VIBE X: {avg("vibe_x")}
VIBE Y: {avg("vibe_y")}
VIBE Z: {avg("vibe_z")}
CPU Temp: {avg("cpu_temp_c")} C
CPU Usage: {avg("cpu_usage_percent")} %
RAM Usage: {avg("ram_usage_percent")} %

Latest Message:
{latest_message}
"""
