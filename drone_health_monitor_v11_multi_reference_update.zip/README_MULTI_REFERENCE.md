# V11 Multi-Reference Marker Update

Template detection now loads references in this exact fallback order:

1. `markers/references/original.png`
2. `markers/references/A.png`
3. `markers/references/B.png`
4. `markers/references/C.png`
5. `markers/references/D.png`
6. `markers/references/E.png`

The program reports:
- reference image used;
- confidence as a percentage;
- time from test start until first detection;
- per-frame processing time;
- best confidence when the marker is not detected.

Marker-only test:

```bash
python src/run_marker_test.py --camera-backend picamera2 --marker-type template --reference markers/references --duration 60 --show --send-email
```

Full health test, dry-run landing only:

```bash
python src/main.py --connection /dev/ttyACM0 --baud 115200 --duration 180 --detect-marker --camera-backend picamera2 --marker-type template --marker-reference markers/references --autoland-on-marker --send-email
```

Do not add `--enable-autolanding` during bench detection tests.
