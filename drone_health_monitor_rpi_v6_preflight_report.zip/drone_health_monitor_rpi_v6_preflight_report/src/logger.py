import csv
from pathlib import Path
from datetime import datetime


class CsvLogger:
    def __init__(self, log_dir: str = "logs"):
        Path(log_dir).mkdir(exist_ok=True)
        filename = datetime.now().strftime("drone_health_%Y%m%d_%H%M%S.csv")
        self.path = Path(log_dir) / filename
        self.file = open(self.path, "w", newline="")
        self.writer = csv.writer(self.file)

        self.writer.writerow([
            "timestamp",

            "heartbeat_count", "mavlink_message_count",
            "seconds_since_heartbeat", "seconds_since_message",

            "armed", "mode", "system_status",

            "battery_voltage_v", "battery_current_a", "battery_remaining_percent",

            "gps_fix_type", "gps_satellites", "gps_hdop",

            "acc_x", "acc_y", "acc_z", "vibration_rms",
            "vibe_x", "vibe_y", "vibe_z",
            "clipping_0", "clipping_1", "clipping_2",

            "rc_rssi", "rc_channel_count",
            "rc_chan1_raw", "rc_chan2_raw", "rc_chan3_raw", "rc_chan4_raw",
            "rc_chan5_raw", "rc_chan6_raw", "rc_chan7_raw", "rc_chan8_raw",

            "servo1", "servo2", "servo3", "servo4",
            "servo5", "servo6", "servo7", "servo8",

            "ekf_flags", "ekf_velocity_variance", "ekf_pos_horiz_variance",
            "ekf_pos_vert_variance", "ekf_compass_variance", "ekf_terrain_alt_variance",

            "onboard_control_sensors_present",
            "onboard_control_sensors_enabled",
            "onboard_control_sensors_health",

            "statustext_errors", "statustext_warnings", "last_statustext",

            "cpu_temp_c", "cpu_usage_percent", "ram_usage_percent",

            "health_status", "health_messages"
        ])

    def write(self, tel, vibration_rms, cpu_temp, cpu_usage, ram_usage, health):
        seconds_since_heartbeat = None
        seconds_since_message = None

        if tel.last_heartbeat_time is not None:
            seconds_since_heartbeat = tel.timestamp - tel.last_heartbeat_time
        if tel.last_message_time is not None:
            seconds_since_message = tel.timestamp - tel.last_message_time

        self.writer.writerow([
            tel.timestamp,

            tel.heartbeat_count, tel.mavlink_message_count,
            seconds_since_heartbeat, seconds_since_message,

            tel.armed, tel.mode, tel.system_status,

            tel.battery_voltage_v, tel.battery_current_a, tel.battery_remaining_percent,

            tel.gps_fix_type, tel.gps_satellites, tel.gps_hdop,

            tel.acc_x, tel.acc_y, tel.acc_z, vibration_rms,
            tel.vibe_x, tel.vibe_y, tel.vibe_z,
            tel.clipping_0, tel.clipping_1, tel.clipping_2,

            tel.rc_rssi, tel.rc_channel_count,
            tel.rc_chan1_raw, tel.rc_chan2_raw, tel.rc_chan3_raw, tel.rc_chan4_raw,
            tel.rc_chan5_raw, tel.rc_chan6_raw, tel.rc_chan7_raw, tel.rc_chan8_raw,

            *tel.servo_outputs[:8],

            tel.ekf_flags, tel.ekf_velocity_variance, tel.ekf_pos_horiz_variance,
            tel.ekf_pos_vert_variance, tel.ekf_compass_variance, tel.ekf_terrain_alt_variance,

            tel.onboard_control_sensors_present,
            tel.onboard_control_sensors_enabled,
            tel.onboard_control_sensors_health,

            tel.statustext_errors, tel.statustext_warnings, tel.last_statustext,

            cpu_temp, cpu_usage, ram_usage,

            health.status, " | ".join(health.messages)
        ])
        self.file.flush()

    def close(self):
        self.file.close()
