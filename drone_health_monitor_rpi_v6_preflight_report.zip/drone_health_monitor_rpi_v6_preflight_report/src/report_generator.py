from pathlib import Path
from datetime import datetime
import pandas as pd


def numeric(df, col):
    if col not in df.columns:
        return pd.Series(dtype=float)
    return pd.to_numeric(df[col], errors="coerce")


def avg(df, col):
    values = numeric(df, col).dropna()
    return None if values.empty else float(values.mean())


def min_val(df, col):
    values = numeric(df, col).dropna()
    return None if values.empty else float(values.min())


def max_val(df, col):
    values = numeric(df, col).dropna()
    return None if values.empty else float(values.max())


def latest_text(df, col):
    if col not in df.columns:
        return None
    values = df[col].dropna()
    if values.empty:
        return None
    return str(values.iloc[-1])


def status_line(name, status, message):
    return f"<tr><td><b>{name}</b></td><td>{status}</td><td>{message}</td></tr>"


def add_result(rows, plain_lines, problems, name, status, message, is_problem=False):
    rows.append(status_line(name, status, message))
    plain_lines.append(f"{name}: {status} — {message}")
    if is_problem:
        problems.append(f"{name}: {message}")


def friendly_status_rows(df):
    rows = []
    plain_lines = []
    problems = []

    # MAVLink / Pixhawk
    msg_count = max_val(df, "mavlink_message_count")
    hb_count = max_val(df, "heartbeat_count")
    mode = latest_text(df, "mode")
    armed = latest_text(df, "armed")

    if msg_count is None or msg_count <= 0 or hb_count is None or hb_count <= 0:
        add_result(rows, plain_lines, problems, "תקשורת Pixhawk ↔ Raspberry Pi", "❌ לא תקין",
                   "לא התקבלה תקשורת MAVLink תקינה מהבקר.", True)
    else:
        add_result(rows, plain_lines, problems, "תקשורת Pixhawk ↔ Raspberry Pi", "✅ תקין",
                   f"התקבלו הודעות MAVLink ו־Heartbeat. מצב טיסה: {mode}, Armed: {armed}.")

    # Flight controller
    if mode:
        add_result(rows, plain_lines, problems, "בקר טיסה", "✅ תקין",
                   f"הבקר מזוהה ומדווח מצב טיסה: {mode}.")
    else:
        add_result(rows, plain_lines, problems, "בקר טיסה", "⚠️ חסר מידע",
                   "לא התקבל מצב טיסה מהבקר.", True)

    # RC / ELRS
    rc_channels = avg(df, "rc_channel_count")
    rc_rssi = avg(df, "rc_rssi")
    ch1 = avg(df, "rc_chan1_raw")
    ch2 = avg(df, "rc_chan2_raw")
    ch3 = avg(df, "rc_chan3_raw")
    ch4 = avg(df, "rc_chan4_raw")

    if rc_channels is None:
        add_result(rows, plain_lines, problems, "שלט RC / ELRS", "⚠️ חסר מידע",
                   "לא התקבלו נתוני RC_CHANNELS. ייתכן שהשלט לא מחובר או שהבקר לא משדר נתוני RC.", True)
    elif rc_channels >= 4:
        if rc_rssi is not None and rc_rssi != 255:
            if rc_rssi >= 60:
                add_result(rows, plain_lines, problems, "שלט RC / ELRS", "✅ תקין",
                           f"זוהו {rc_channels:.0f} ערוצים. RSSI ממוצע: {rc_rssi:.0f}. ערוצים 1–4: {ch1:.0f}, {ch2:.0f}, {ch3:.0f}, {ch4:.0f}.")
            elif rc_rssi >= 40:
                add_result(rows, plain_lines, problems, "שלט RC / ELRS", "⚠️ גבולי",
                           f"זוהו {rc_channels:.0f} ערוצים אך RSSI ממוצע נמוך יחסית: {rc_rssi:.0f}.", True)
            else:
                add_result(rows, plain_lines, problems, "שלט RC / ELRS", "❌ לא תקין",
                           f"RSSI נמוך מאוד: {rc_rssi:.0f}.", True)
        else:
            add_result(rows, plain_lines, problems, "שלט RC / ELRS", "✅ תקין",
                       f"זוהו {rc_channels:.0f} ערוצים. RSSI לא זמין/לא מדווח, אך ערוצי RC מתקבלים.")
    else:
        add_result(rows, plain_lines, problems, "שלט RC / ELRS", "❌ לא תקין",
                   f"זוהו רק {rc_channels:.0f} ערוצים. נדרשים לפחות 4 ערוצים.", True)

    # Battery
    battery_v = avg(df, "battery_voltage_v")
    battery_min = min_val(df, "battery_voltage_v")
    battery_percent = avg(df, "battery_remaining_percent")

    if battery_v is None:
        add_result(rows, plain_lines, problems, "סוללה", "⚠️ חסר מידע",
                   "לא התקבלו נתוני סוללה מהבקר.", True)
    elif battery_v >= 21.0:
        add_result(rows, plain_lines, problems, "סוללה", "✅ תקינה",
                   f"תקינה לשימוש — מתח ממוצע {battery_v:.2f}V, מתח מינימלי {battery_min:.2f}V, אחוז ממוצע {battery_percent:.0f}%.")
    elif battery_v >= 20.0:
        add_result(rows, plain_lines, problems, "סוללה", "⚠️ אזהרה",
                   f"מתח ממוצע {battery_v:.2f}V. מומלץ להטעין לפני טיסה.", True)
    else:
        add_result(rows, plain_lines, problems, "סוללה", "❌ לא תקינה",
                   f"מתח ממוצע {battery_v:.2f}V נמוך מדי.", True)

    # GPS
    gps_fix = avg(df, "gps_fix_type")
    sats = avg(df, "gps_satellites")
    hdop = avg(df, "gps_hdop")

    if gps_fix is None or sats is None or hdop is None:
        add_result(rows, plain_lines, problems, "GPS", "⚠️ חסר מידע",
                   "לא התקבלו נתוני GPS מלאים.", True)
    elif gps_fix >= 3 and sats >= 8 and hdop < 1.5:
        add_result(rows, plain_lines, problems, "GPS", "✅ תקין",
                   f"Fix Type {gps_fix:.0f}, ממוצע {sats:.0f} לוויינים, HDOP ממוצע {hdop:.2f}.")
    elif gps_fix >= 3 and sats >= 8 and hdop < 2.5:
        add_result(rows, plain_lines, problems, "GPS", "⚠️ גבולי",
                   f"HDOP ממוצע {hdop:.2f}. מומלץ לבדוק בחוץ או ליד חלון.", True)
    else:
        add_result(rows, plain_lines, problems, "GPS", "❌ לא יציב",
                   f"Fix Type {gps_fix:.0f}, לוויינים {sats:.0f}, HDOP {hdop:.2f}.", True)

    # EKF
    ekf_vel = avg(df, "ekf_velocity_variance")
    ekf_horiz = avg(df, "ekf_pos_horiz_variance")
    ekf_vert = avg(df, "ekf_pos_vert_variance")
    ekf_compass = avg(df, "ekf_compass_variance")

    if all(v is None for v in [ekf_vel, ekf_horiz, ekf_vert, ekf_compass]):
        add_result(rows, plain_lines, problems, "EKF", "⚠️ חסר מידע",
                   "לא התקבלו נתוני EKF_STATUS_REPORT.", True)
    elif max(v for v in [ekf_vel or 0, ekf_horiz or 0, ekf_vert or 0, ekf_compass or 0]) < 1.0:
        add_result(rows, plain_lines, problems, "EKF", "✅ תקין",
                   f"שגיאות/Variance נמוכות. Compass variance ממוצע {ekf_compass:.2f}.")
    else:
        add_result(rows, plain_lines, problems, "EKF", "⚠️ אזהרה",
                   f"נמדדה Variance גבוהה יחסית. Velocity={ekf_vel}, Position={ekf_horiz}, Compass={ekf_compass}.", True)

    # Compass via EKF compass variance
    if ekf_compass is None:
        add_result(rows, plain_lines, problems, "מצפן", "⚠️ חסר מידע",
                   "לא התקבלה בדיקת מצפן דרך EKF.", True)
    elif ekf_compass < 0.5:
        add_result(rows, plain_lines, problems, "מצפן", "✅ תקין",
                   f"Compass variance ממוצע {ekf_compass:.2f}.")
    elif ekf_compass < 1.0:
        add_result(rows, plain_lines, problems, "מצפן", "⚠️ גבולי",
                   f"Compass variance ממוצע {ekf_compass:.2f}. מומלץ לבדוק כיול והרחקה ממתכות.", True)
    else:
        add_result(rows, plain_lines, problems, "מצפן", "❌ לא תקין",
                   f"Compass variance גבוהה: {ekf_compass:.2f}.", True)

    # IMU / Vibration
    vib = avg(df, "vibration_rms")
    vibe_x = avg(df, "vibe_x")
    vibe_y = avg(df, "vibe_y")
    vibe_z = avg(df, "vibe_z")
    max_vibe = max([v for v in [vibe_x, vibe_y, vibe_z] if v is not None], default=None)

    if vib is None:
        add_result(rows, plain_lines, problems, "רעידות IMU", "⚠️ חסר מידע",
                   "לא נאספו מספיק דגימות רעידות.", True)
    elif vib < 3.0 and (max_vibe is None or max_vibe < 30):
        add_result(rows, plain_lines, problems, "רעידות IMU", "✅ תקין",
                   f"RMS ממוצע {vib:.3f} m/s², VIBE מקסימלי ממוצע {max_vibe:.3f}.")
    elif vib < 6.0:
        add_result(rows, plain_lines, problems, "רעידות IMU", "⚠️ גבולי",
                   f"RMS ממוצע {vib:.2f} m/s². כדאי לבדוק ברגים, מנועים ואיזון פרופלורים.", True)
    else:
        add_result(rows, plain_lines, problems, "רעידות IMU", "❌ לא תקין",
                   f"RMS ממוצע {vib:.2f} m/s² גבוה מדי.", True)

    clip0 = max_val(df, "clipping_0") or 0
    clip1 = max_val(df, "clipping_1") or 0
    clip2 = max_val(df, "clipping_2") or 0

    if clip0 == 0 and clip1 == 0 and clip2 == 0:
        add_result(rows, plain_lines, problems, "IMU Clipping", "✅ תקין",
                   "לא זוהו חריגות Clipping בחיישני ה־IMU.")
    else:
        add_result(rows, plain_lines, problems, "IMU Clipping", "⚠️ אזהרה",
                   f"זוהה Clipping: {clip0}, {clip1}, {clip2}.", True)

    # PWM / Motors
    servo_values = [avg(df, f"servo{i}") for i in range(1, 5)]
    if all(v is None for v in servo_values):
        add_result(rows, plain_lines, problems, "מנועים / PWM", "⚠️ חסר מידע",
                   "לא התקבלו נתוני SERVO_OUTPUT_RAW.", True)
    elif all((v is not None and v == 0) for v in servo_values):
        add_result(rows, plain_lines, problems, "מנועים / PWM", "✅ תקין במצב DISARM",
                   "יציאות המנועים 1–4 הן 0, וזה תקין כאשר הרחפן לא חמוש.")
    elif sum(1 for v in servo_values if v is not None and v > 900) >= 4:
        add_result(rows, plain_lines, problems, "מנועים / PWM", "✅ פעיל",
                   f"יציאות PWM מזוהות בערוצים 1–4: {', '.join(str(int(v)) for v in servo_values)}.")
    else:
        add_result(rows, plain_lines, problems, "מנועים / PWM", "⚠️ גבולי",
                   f"נתוני PWM חלקיים: {servo_values}.", True)

    # Autopilot status text
    errors = max_val(df, "statustext_errors") or 0
    warnings = max_val(df, "statustext_warnings") or 0
    last_text = latest_text(df, "last_statustext")
    if errors > 0:
        add_result(rows, plain_lines, problems, "הודעות בקר טיסה", "⚠️ אזהרה",
                   f"זוהו {errors:.0f} הודעות שגיאה. הודעה אחרונה: {last_text}", True)
    elif warnings > 0:
        add_result(rows, plain_lines, problems, "הודעות בקר טיסה", "⚠️ אזהרה",
                   f"זוהו {warnings:.0f} הודעות אזהרה. הודעה אחרונה: {last_text}", True)
    else:
        add_result(rows, plain_lines, problems, "הודעות בקר טיסה", "✅ תקין",
                   "לא זוהו הודעות שגיאה/אזהרה מהבקר במהלך הבדיקה.")

    # Raspberry Pi
    cpu_temp = avg(df, "cpu_temp_c")
    cpu_usage = avg(df, "cpu_usage_percent")
    ram_usage = avg(df, "ram_usage_percent")

    if cpu_temp is None:
        add_result(rows, plain_lines, problems, "Raspberry Pi", "⚠️ חסר מידע",
                   "לא התקבלו נתוני טמפרטורת CPU.", True)
    elif cpu_temp < 70 and cpu_usage < 85 and ram_usage < 85:
        add_result(rows, plain_lines, problems, "Raspberry Pi", "✅ תקין",
                   f"טמפרטורת CPU ממוצעת {cpu_temp:.1f}°C, שימוש CPU {cpu_usage:.1f}%, RAM {ram_usage:.1f}%.")
    else:
        add_result(rows, plain_lines, problems, "Raspberry Pi", "⚠️ אזהרה",
                   f"טמפ׳ {cpu_temp:.1f}°C, CPU {cpu_usage:.1f}%, RAM {ram_usage:.1f}%.", True)

    return rows, plain_lines, problems


def metric_row(df, label, col, unit=""):
    values = numeric(df, col).dropna()
    if values.empty:
        return f"<tr><td>{label}</td><td>N/A</td><td>N/A</td><td>N/A</td><td>{unit}</td></tr>"
    return (
        f"<tr><td>{label}</td>"
        f"<td>{values.mean():.2f}</td>"
        f"<td>{values.min():.2f}</td>"
        f"<td>{values.max():.2f}</td>"
        f"<td>{unit}</td></tr>"
    )


def generate_report(log_path: str, out_dir: str = "reports") -> Path:
    df = pd.read_csv(log_path)
    Path(out_dir).mkdir(exist_ok=True)

    friendly_rows, plain_lines, problems = friendly_status_rows(df)
    status_counts = df["health_status"].value_counts().to_dict() if "health_status" in df else {}

    if problems:
        overall_status = "❌ לא מוכן לטיסה"
        overall_reason = "<br>".join(problems)
    else:
        overall_status = "✅ מוכן לטיסה"
        overall_reason = "כל המערכות המרכזיות תקינות לפי הבדיקה."

    metric_rows = [
        metric_row(df, "MAVLink Messages", "mavlink_message_count", ""),
        metric_row(df, "Heartbeat Count", "heartbeat_count", ""),
        metric_row(df, "RC RSSI", "rc_rssi", ""),
        metric_row(df, "RC Channel Count", "rc_channel_count", ""),
        metric_row(df, "Battery Voltage", "battery_voltage_v", "V"),
        metric_row(df, "Battery Current", "battery_current_a", "A"),
        metric_row(df, "GPS Satellites", "gps_satellites", ""),
        metric_row(df, "GPS HDOP", "gps_hdop", ""),
        metric_row(df, "EKF Compass Variance", "ekf_compass_variance", ""),
        metric_row(df, "EKF Velocity Variance", "ekf_velocity_variance", ""),
        metric_row(df, "RAW_IMU Vibration RMS", "vibration_rms", "m/s²"),
        metric_row(df, "VIBE X", "vibe_x", ""),
        metric_row(df, "VIBE Y", "vibe_y", ""),
        metric_row(df, "VIBE Z", "vibe_z", ""),
        metric_row(df, "CPU Temperature", "cpu_temp_c", "°C"),
        metric_row(df, "CPU Usage", "cpu_usage_percent", "%"),
        metric_row(df, "RAM Usage", "ram_usage_percent", "%"),
    ]

    html = f"""<!doctype html>
<html lang="he" dir="rtl">
<head>
<meta charset="utf-8">
<title>Drone Pre-Flight Health Report</title>
<style>
body {{ font-family: Arial, sans-serif; margin: 30px; direction: rtl; }}
table {{ border-collapse: collapse; width: 100%; margin-top: 10px; }}
td, th {{ border: 1px solid #cccccc; padding: 10px; text-align: right; }}
th {{ background: #eeeeee; }}
.box {{ background: #f7f7f7; border: 1px solid #dddddd; padding: 15px; border-radius: 8px; margin-bottom: 20px; }}
.overall {{ font-size: 22px; font-weight: bold; }}
</style>
</head>
<body>
<h1>דוח תקינות Pre-Flight לרחפן</h1>
<p><b>תאריך יצירה:</b> {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}</p>
<p><b>קובץ לוג:</b> {Path(log_path).name}</p>
<p><b>מספר דגימות:</b> {len(df)}</p>

<div class="box">
<h2>סטטוס כללי</h2>
<p class="overall">{overall_status}</p>
<p>{overall_reason}</p>
</div>

<div class="box">
<h2>סיכום פשוט למשתמש</h2>
<table>
<tr><th>מערכת</th><th>מצב</th><th>פירוט</th></tr>
{''.join(friendly_rows)}
</table>
</div>

<h2>נתונים מספריים</h2>
<table>
<tr><th>מדד</th><th>ממוצע</th><th>מינימום</th><th>מקסימום</th><th>יחידה</th></tr>
{''.join(metric_rows)}
</table>

<h2>ספירת מצבי מערכת</h2>
<pre>{status_counts}</pre>

<h2>הערה</h2>
<p>
הדוח מיועד לבדיקה התחלתית. לפני טיסה אמיתית יש לבדוק גם ב־Mission Planner/QGroundControl:
ARM, GPS, EKF, מצפן, כיוון מנועים ו־Failsafe.
</p>
</body>
</html>"""

    report_path = Path(out_dir) / f"preflight_drone_health_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.html"
    report_path.write_text(html, encoding="utf-8")
    return report_path


def text_summary(log_path: str) -> str:
    df = pd.read_csv(log_path)
    _, plain_lines, problems = friendly_status_rows(df)

    if problems:
        overall = "סטטוס כללי: לא מוכן לטיסה ❌"
        problem_text = "\n".join(f"- {p}" for p in problems)
    else:
        overall = "סטטוס כללי: מוכן לטיסה ✅"
        problem_text = "לא נמצאו בעיות מרכזיות."

    return f"""דוח תקינות Pre-Flight לרחפן

{overall}

סיבות/הערות:
{problem_text}

סיכום מערכות:
{chr(10).join(plain_lines)}

מספר דגימות: {len(df)}

מצורפים למייל:
1. דוח HTML ידידותי
2. קובץ CSV מלא עם כל הנתונים
"""
